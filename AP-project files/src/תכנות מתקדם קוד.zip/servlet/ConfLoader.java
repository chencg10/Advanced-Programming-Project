package servlet;
import graph.GenericConfig;
import graph.Graph;
import server.RequestParser;
import views.HtmlGraphWriter;

import java.io.*;
import java.util.*;
import java.nio.file.*;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class ConfLoader implements Servlet{

    private PrintWriter clientOut;
    @Override
    public void handle(RequestParser.RequestInfo ri, OutputStream toClient) throws IOException {

        // use a print writer to write the response
        clientOut = new PrintWriter(toClient);

        // reset the topics map in the TopicDisplayer servlet
        TopicDisplayer.resetTopicsAndMessages();

        // get the file name from the parameters:
        String fileName = ri.getParameters().get("filename");
        //System.out.println("---exctracted file name: " + fileName);

        // trim the quotes from the file name:
        if (fileName != null) {
            fileName = fileName.replace("\"", "");
        }


        // get the file content from the body:
        String fileContent = new String(ri.getContent(), StandardCharsets.UTF_8);
//        System.out.println("--File content: " + fileContent);
        // print the file content
        //System.out.println("---exctracted file content: \n" + fileContent);
        Path filePath;
        // If file was uploaded, save it
        if (fileName != null) {
            String currentWorkingDirectory = System.getProperty("user.dir") + "/uploads";
            Path directoryPath = Paths.get(currentWorkingDirectory);
            Files.createDirectories(directoryPath);
            // save the content as a .conf file:
            filePath = Paths.get(currentWorkingDirectory + "/" + fileName);
            Files.writeString(filePath, fileContent);
            //System.out.println("File " + fileName + " uploaded successfully.");
        } else {
            System.out.println("No file uploaded.");
            filePath = null;
        }

        // create graph from config file
        GenericConfig config = new GenericConfig();
        config.setConfFile(String.valueOf(filePath));
        config.create();

        // create graph
        Graph graph = new Graph();
        graph.createFromTopics();

        // verify that the graph has no cycles
        if (graph.hasCycles()) {
            // sent an html response to the client that the graph has cycles
            String path = System.getProperty("user.dir") + "/html_files";
            String htmlContent = HtmlLoader.readFileToString(new File(path + "/cycles.html"));
            clientOut.println("HTTP/1.1 200 OK");
            clientOut.println("Content-Type: text/html");
            clientOut.println("Connection: close");
            clientOut.println("Content-Length: " + htmlContent.length());
            clientOut.println();
            clientOut.println(htmlContent);
            clientOut.flush();
            return;
        }


        // create the graph html
        HtmlGraphWriter.getGraphHTML(graph);


        // change path to the html_files directory
        String path = System.getProperty("user.dir") + "/html_files";
        String htmlContent = HtmlLoader.readFileToString(new File(path + "/graph.html"));
        clientOut.println("HTTP/1.1 200 OK");
        clientOut.println("Content-Type: text/html");
        clientOut.println("Connection: close");
        clientOut.println("Content-Length: " + htmlContent.length());
        clientOut.println();
        clientOut.println(htmlContent);
        clientOut.flush();
    }

    @Override
    public void close() throws IOException {
        // Any cleanup code can go here
        clientOut.close();
    }

    private String getBoundary(String contentType) {
        if (contentType == null) return null;
        for (String param : contentType.split(";")) {
            param = param.trim();
            if (param.startsWith("boundary=")) {
                return param.substring("boundary=".length());
            }
        }
        return null;
    }

    private String getFileName(String contentDisposition) {
        for (String param : contentDisposition.split(";")) {
            param = param.trim();
            if (param.startsWith("filename=")) {
                return param.substring("filename=".length()).replace("\"", "");
            }
        }
        return null;
    }

//    public static void main(String[] args) {
//        // Test the getFileName method
//        String http_request = """
//                POST /upload HTTP/1.1
//                Host: example.com
//                Content-Type: multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW
//                Content-Length: 52
//
//                ----WebKitFormBoundary7MA4YWxkTrZu0gW
//                Content-Disposition: form-data;
//                name="configFile";
//                filename="config.conf"
//                Content-Type: text/plain
//
//                EX1.configs.PlusAgent
//                A,B
//                C
//                EX1.configs.IncAgent
//                C
//                D
//
//                ----WebKitFormBoundary7MA4YWxkTrZu0gW--
//                """;
//        BufferedReader input = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(http_request.getBytes())));
//        try {
//            server.RequestParser.RequestInfo requestInfo = server.RequestParser.parseRequest(input);
//            ConfLoader confLoader = new ConfLoader();
//            assert requestInfo != null;
//            confLoader.handle(requestInfo, System.out);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
}




/*
 implemnet the ConfLoader servlet so that it handels the first form of the form.html file : . It will exctract the name of the file and its content, save the content in the server side. Load the GenericConfig according to the file content and create an instance of the Graph from the config file. Anser an http answer that conatins the HTML of the graphic calc graph
*/