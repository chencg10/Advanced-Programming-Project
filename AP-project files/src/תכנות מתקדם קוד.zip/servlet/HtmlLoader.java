package servlet;
import server.RequestParser;
import java.io.*;


public class HtmlLoader implements Servlet {
    private final String path;
    private PrintWriter clientOut;

    public HtmlLoader(String path) {
        // Save the path to the HTML files
        this.path = path;
    }

    @Override
    public void handle(RequestParser.RequestInfo ri, OutputStream toClient) throws IOException {

        clientOut = new PrintWriter(toClient);

        // get the uri
        String uri = ri.getUri();
        //System.out.println("--URI: " + uri);

        // check if the uri starts with /app
        if (uri.startsWith("/app/")) {
            // get the html file name
            String fileName = ri.getUriSegments()[1];

            // check if the html file exists in the html_files directory
            File file = new File(path + "/" + fileName);
            // print the path
            //System.out.println("--Path: " + file.getAbsolutePath());
            if (!file.exists()) {
                // write the response
                clientOut.println("HTTP/1.1 404 Not Found");
                clientOut.println();
                clientOut.println("404 Not Found");
                clientOut.flush();
                return;
            }


            // get the html file content
            String fileContent = readFileToString(file);
            // write the response
            toClient.write("HTTP/1.1 200 OK\n".getBytes());
//            clientOut.println("HTTP/1.1 200 OK");
            // if the content is an html file, set the content type to text/html
            if (fileName.endsWith(".html"))
                toClient.write("Content-Type: text/html\n".getBytes());
//                clientOut.println("Content-Type: text/html");
            else if (fileName.endsWith(".css"))
                toClient.write("Content-Type: text/css\n".getBytes());
//                clientOut.println("Content-Type: text/css");

            toClient.write(("Content-Length: " + fileContent.length() + "\n\n").getBytes());
//            clientOut.println("Content-Length: " + fileContent.length());
//            clientOut.println();
            toClient.write(fileContent.getBytes());
//            clientOut.println(fileContent);
//            clientOut.flush();
            toClient.flush();
        }
    }

    public static String readFileToString(File file) throws IOException {
        StringBuilder fileContent = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                fileContent.append(line).append("\n"); // Append newline for each line read
            }
        }
        return fileContent.toString();
    }

    @Override
    public void close() throws IOException {
        clientOut.close();

    }

//    public static void main(String[] args) {
//        String httpCommand = """
//               GET /app/index.html HTTP/1.1
//               Host: localhost:8080
//               Connection: keep-alive
//               Cache-Control: max-age=0
//               sec-ch-ua: "Not/A)Brand";v="8", "Chromium";v="126", "Google Chrome";v="126"
//               sec-ch-ua-mobile: ?0
//               sec-ch-ua-platform: "macOS"
//               Upgrade-Insecure-Requests: 1
//               User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36
//               Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
//               Sec-Fetch-Site: cross-site
//               Sec-Fetch-Mode: navigate
//               Sec-Fetch-User: ?1
//               Sec-Fetch-Dest: document
//               Accept-Encoding: gzip, deflate, br, zstd
//               Accept-Language: he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7
//
//               """;
//        BufferedReader input = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(httpCommand.getBytes())));
//        try {
//            server.RequestParser.RequestInfo requestInfo = server.RequestParser.parseRequest(input);
//            String currentWorkingDirectory = System.getProperty("user.dir") + "/html_files";
//            HtmlLoader htmlLoader = new HtmlLoader(currentWorkingDirectory);
//            assert requestInfo != null;
//            htmlLoader.handle(requestInfo, System.out);
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }
//    }
}
