package servlet;

import graph.GenericConfig;
import graph.Graph;
import graph.Message;
import graph.TopicManagerSingleton;
import graph.TopicManagerSingleton.TopicManager;
import server.RequestParser;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class TopicDisplayer implements Servlet {
    private static Map<String, String> topicsAndMessages = new ConcurrentHashMap<>();
    private PrintWriter clientOut;

    @Override
    public void handle(RequestParser.RequestInfo ri, OutputStream toClient) throws IOException {

        // initialize the table
        TopicManager tm = TopicManagerSingleton.get();
        clientOut = new PrintWriter(toClient);
        // check if there are any topics in the topic manager
        if (!tm.getTopics().isEmpty()) {
            // get all topics and their last messages
            for (String topicName : tm.getTopics().keySet()) {
                // if the topic has a 'T' prefix, remove it
                if (topicName.startsWith("T")) {
                    topicName = topicName.substring(1);
                }
                topicsAndMessages.put("T" + topicName, tm.getTopic(topicName).getLastMessage().getContent());
            }

            // get the topic name and message from the http request
            // Extracting the topic and message names from the HTTP request
            Map<String, String> params = ri.getParameters();
            String topicName = params.get("Topic+name");
            String message = params.get("Message");

            // check if the topic name is in the map, if not return
            Set<String> topic_names_set = topicsAndMessages.keySet();
            if (!topic_names_set.contains(topicName)) {
                return;
            }

            // Publish the message to the topic using TopicManager
            tm.getTopic(topicName.substring(1)).publish(new Message(message));
            // Getting the last message from all topics and update the map
            for (String topic : topic_names_set) {
                topicsAndMessages.put(topic, tm.getTopic(topic.substring(1)).getLastMessage().getContent());
            }

            StringBuilder htmlContent = new StringBuilder("<html>" +
                    "<body>" +
                    "<table border='1'>" +
                    "<tr><th>Topic Name</th><th>Last Message</th></tr>");
            for (Map.Entry<String, String> entry : topicsAndMessages.entrySet()) {
                htmlContent.append("<tr><td>")
                        .append(entry.getKey())
                        .append("</td><td>")
                        .append(entry.getValue())
                        .append("</td></tr>");
            }
            htmlContent.append("</table>" + "</body></html>");

            // Generate http response
            clientOut.println("HTTP/1.1 200 OK");
            clientOut.println("Content-Type: text/html");
            clientOut.println("Content-Length: " + htmlContent.length());
            clientOut.println();
            clientOut.println(htmlContent);
            clientOut.flush();
        }
        // if there is no graph loaded:
        else {
            // load the temp.html and send it as a response
            String path = System.getProperty("user.dir") + "/html_files";
            String htmlContent = HtmlLoader.readFileToString(new File(path + "/temp.html"));
            clientOut.println("HTTP/1.1 200 OK");
            clientOut.println("Content-Type: text/html");
            clientOut.println("Connection: close");
            clientOut.println("Content-Length: " + htmlContent.length());
            clientOut.println();
            clientOut.println(htmlContent);
            clientOut.flush();
        }
    }

    public static void resetTopicsAndMessages() {
        // reset the map by overwriting it with a new one
        topicsAndMessages.clear();
        TopicManager tm = TopicManagerSingleton.get();
        tm.clear();
    }

    // Implementing the close method
    @Override
    public void close() throws IOException {
        clientOut.close();
    }

//    public static void main(String[] args) {
//        String http_req = """
//                GET /publish?Topic+name=TA&Message=1 HTTP/1.1
//                Host: localhost:8080
//                Connection: keep-alive
//                sec-ch-ua: "Not/A)Brand";v="8", "Chromium";v="126", "Google Chrome";v="126"
//                sec-ch-ua-mobile: ?0
//                sec-ch-ua-platform: "macOS"
//                Upgrade-Insecure-Requests: 1
//                User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36
//                Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
//                Sec-Fetch-Site: same-origin
//                Sec-Fetch-Mode: navigate
//                Sec-Fetch-User: ?1
//                Sec-Fetch-Dest: iframe
//                Referer: http://localhost:8080/app/form.html
//                Accept-Encoding: gzip, deflate, br, zstd
//                Accept-Language: he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7
//                Cookie: Idea-a24beeec=aa279d8e-d87e-4c09-b6e9-c2f360d27466
//
//                """;
//
//        BufferedReader input = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(http_req.getBytes())));
//        // create a graph
//        String path = System.getProperty("user.dir") + "/uploads/simple.conf";
//        GenericConfig config = new GenericConfig();
//        config.setConfFile(path);
//        config.create();
//
//        Graph graph = new Graph();
//        graph.createFromTopics();
//
//        TopicDisplayer topicDisplayer = new TopicDisplayer();
//
//        try {
//            server.RequestParser.RequestInfo requestInfo = server.RequestParser.parseRequest(input);
//            assert requestInfo != null;
//            topicDisplayer.handle(requestInfo, System.out);
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }
//
//         http_req = """
//                GET /publish?Topic+name=TB&Message=1 HTTP/1.1
//                Host: localhost:8080
//                Connection: keep-alive
//                sec-ch-ua: "Not/A)Brand";v="8", "Chromium";v="126", "Google Chrome";v="126"
//                sec-ch-ua-mobile: ?0
//                sec-ch-ua-platform: "macOS"
//                Upgrade-Insecure-Requests: 1
//                User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36
//                Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
//                Sec-Fetch-Site: same-origin
//                Sec-Fetch-Mode: navigate
//                Sec-Fetch-User: ?1
//                Sec-Fetch-Dest: iframe
//                Referer: http://localhost:8080/app/form.html
//                Accept-Encoding: gzip, deflate, br, zstd
//                Accept-Language: he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7
//                Cookie: Idea-a24beeec=aa279d8e-d87e-4c09-b6e9-c2f360d27466
//
//                """;
//        input = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(http_req.getBytes())));
//
//        try {
//            server.RequestParser.RequestInfo requestInfo = server.RequestParser.parseRequest(input);
//            assert requestInfo != null;
//            topicDisplayer.handle(requestInfo, System.out);
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }
//    }

}
