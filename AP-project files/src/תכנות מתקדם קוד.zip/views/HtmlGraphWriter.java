package views;

import configs.Node;
import graph.GenericConfig;
import graph.Graph;
import servlet.HtmlLoader;

import java.io.File;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

public class HtmlGraphWriter {

    public static void getGraphHTML(Graph g) {

        // read the temp_graph.html file content
        String path = System.getProperty("user.dir") + "/html_files";
        String htmlContent = "";
        try {
             htmlContent = HtmlLoader.readFileToString(new File(path + "/temp_graph.html"));

        } catch (Exception ignored) {

        }

        // get nodes names and index them
        StringBuilder nodes = new StringBuilder();
        Map<String, Integer> nodeToIndex = new HashMap<>();

        nodes.append("[ ");
        for (int i = 0; i < g.size(); i++) {
            // get the node
            Node node = g.get(i);
            // append the node to the node's string
            nodes.append("{id: ").append(i+1).append(", label: \"").append(node.getName()).append("\"} ");
            if (i != g.size() - 1) {
                nodes.append(", ");
            }
            // save the index of the node
            nodeToIndex.put(node.getName(), i+1);
        }
        nodes.append("];");

        // get edges
        StringBuilder edges = new StringBuilder();
        edges.append("[ ");
        for (int i = 0; i < g.size(); i++) {
            for (Node node : g.get(i).getEdges()) {
                // get node index
                int index = nodeToIndex.get(node.getName());
                // append the edge
                edges.append("{source: ").append(i + 1).append(", target: ").append(index).append("}");
                if (i != g.size() - 1) {
                    edges.append(", ");
                }
            }
        }
        edges.append("];");


        // insert the nodes and edges into the html content
        htmlContent = htmlContent.replace("NODE_PLACEHOLDER;", nodes);
        htmlContent = htmlContent.replace("LINK_PLACEHOLDER;", edges);

        // save the new html content into a new file
        try {
            Files.write(Paths.get(path + "/graph.html"), htmlContent.getBytes());
        } catch (Exception e) {
            e.printStackTrace();
        }

        //System.out.println("Graph HTML file created successfully.");
    }
}
