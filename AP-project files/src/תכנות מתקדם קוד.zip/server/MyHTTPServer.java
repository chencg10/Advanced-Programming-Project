package server;

import servlet.Servlet;

import java.io.*;
import java.net.Socket;
import java.util.Map;
import java.util.concurrent.*;
import java.net.ServerSocket;

public class MyHTTPServer extends Thread implements HTTPServer{
    // create a map for each http command
    private ConcurrentHashMap<String,Servlet> get_map = new ConcurrentHashMap<>();
    private ConcurrentHashMap<String,Servlet> post_map = new ConcurrentHashMap<>();
    private ConcurrentHashMap<String,Servlet> delete_map = new ConcurrentHashMap<>();
    // create a thread pool
    private ExecutorService threadPool;
    // create a server socket
    private ServerSocket serverSocket;
    // create a flag to stop the server
    private volatile boolean stopServer = false;
    final private int portNum;
    final private int nThreads;

    public MyHTTPServer(int port,int nThreads){
        // set up the thread pool with nThreads threads max
        threadPool = Executors.newFixedThreadPool(nThreads);
        // set the port number
        portNum = port;
        // set the number of threads
        this.nThreads = nThreads;
    }

    public void addServlet(String httpCommanmd, String uri, Servlet s){
        // check for null inputs
        if (uri == null || s == null) {
            return;
        }

        httpCommanmd = httpCommanmd.toUpperCase();

        switch (httpCommanmd) {
            case "GET":
                get_map.put(uri, s);
                break;
            case "POST":
                post_map.put(uri, s);
                break;
            case "DELETE":
                delete_map.put(uri, s);
                break;
        }

    }

    public void removeServlet(String httpCommanmd, String uri){
        if (uri == null) {
            return;
        }

        httpCommanmd = httpCommanmd.toUpperCase();

        switch (httpCommanmd) {
            case "GET":
                get_map.remove(uri);
                break;
            case "POST":
                post_map.remove(uri);
                break;
            case "DELETE":
                delete_map.remove(uri);
                break;
        }
    }


    public void run(){
        // create the server socket
        try (ServerSocket serverSocket = new ServerSocket(portNum)) {
            //System.out.println("inside run after sleep");

            // define 1s timeout
            serverSocket.setSoTimeout(1000);

            //System.out.println("inside run after sleep");


            while (!stopServer) {
                try {
                    //System.out.println("inside run after sleep");
                    // accept a new connection
                    Socket client = serverSocket.accept();

                    // each connected client will go through this procedure when I connects to the server
                    threadPool.submit(() -> {
                        try {
//                            // print all active threads
//                            for (Thread t : Thread.getAllStackTraces().keySet()) {
//                                System.out.println(t.getName());
//                            }

                            // delay for receiving the request correctly:
                            Thread.sleep(125);
                            // get the client input:
                            BufferedReader reader = getBufferedReader(client);

                            // parse the request
                            RequestParser.RequestInfo ri  = RequestParser.parseRequest(reader);
                            ConcurrentHashMap<String, Servlet> servletMap;
                            if (ri != null) {
                                switch (ri.getHttpCommand()) {
                                    case "GET":
                                        servletMap = get_map;
                                        break;
                                    case "POST":
                                        servletMap = post_map;
                                        break;
                                    case "DELETE":
                                        servletMap = delete_map;
                                        break;
                                    default:
                                        throw new IllegalArgumentException("Unsupported HTTP command: " + ri.getHttpCommand());
                                }

                                // search for the longest uri match:
                                String longestMatch = "";
                                Servlet servlet = null;
                                for (Map.Entry<String, Servlet> entry : servletMap.entrySet()) {
                                    if (ri.getUri().startsWith(entry.getKey()) && entry.getKey().length() > longestMatch.length()) {
                                        longestMatch = entry.getKey();
                                        servlet = entry.getValue();
                                    }
                                }

                                // if servlet is not null, activate the handle() method
                                if (servlet != null) {
                                    servlet.handle(ri, client.getOutputStream());
                                }
                            }
                            reader.close();
                        }
                        catch (IOException e) {
                            //System.out.println("Timeout expired and no request was received.");
                            e.printStackTrace();
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        } finally {

                            // close the client socket
                            try {
                                client.close();
//                                System.out.println("-- CLOSED THE CLIENT SOCKET --");
//                                System.out.println(Thread.activeCount());

                            } catch (IOException e) {
                                //System.out.println("IOException 1");
                                e.printStackTrace();
                            }
                        }
                    });
                } catch (IOException e) {
                    // accept() timeout exception, do nothing
                    // if the server is closed, break
                    if (stopServer) {
                        break;
                    }
                }
            }
        } catch (IOException e) {
            // timeout exception, do nothing
        }
    }

    private static BufferedReader getBufferedReader(Socket client) throws IOException {
        InputStream inputStream = client.getInputStream();
        int availableBytes = inputStream.available();
        byte[] buffer = new byte[availableBytes];
        int bytesRead = inputStream.read(buffer, 0, availableBytes);

        return new BufferedReader(
            new InputStreamReader(
                new ByteArrayInputStream(buffer, 0, bytesRead)
            )
        );
    }


    public void start(){
        stopServer = false;
        super.start();
    }

    public void close(){
        //System.out.println(stopServer);
        stopServer = true;
        //System.out.println(stopServer);
        threadPool.shutdownNow();
    }

    public Object getThreadPool() {
        return threadPool;
    }
}


