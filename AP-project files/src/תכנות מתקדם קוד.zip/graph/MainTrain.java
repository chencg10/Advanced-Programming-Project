////package graph;
////
////import java.io.BufferedReader;
////import java.io.ByteArrayInputStream;
////import java.io.IOException;
////import java.io.InputStreamReader;
////import java.io.OutputStream;
////import java.net.Socket;
////import java.util.Arrays;
////import java.util.HashMap;
////import java.util.Map;
////import java.util.concurrent.ThreadPoolExecutor;
////
////import server.MyHTTPServer;
////import server.RequestParser;
////import servlet.SubServlet;
////
////public class MainTrain { // RequestParser
////
////
////    private static void testParseRequest() {
////        // Test data
////
////        String request = "GET /api/resource?id=123&name=test HTTP/1.1\n" +
////                            "Host: example.com\n" +
////                            "Content-Length: 5\n"+
////                            "\n" +
////                            "filename=\"hello_world.txt\"\n"+
////                            "\n" +
////                            "hello world!\n"+
////                            "\n" ;
////
////        BufferedReader input=new BufferedReader(new InputStreamReader(new ByteArrayInputStream(request.getBytes())));
////        try {
////            RequestParser.RequestInfo requestInfo = RequestParser.parseRequest(input);
////
////            // Test HTTP command
////            if (!requestInfo.getHttpCommand().equals("GET")) {
////                System.out.println("HTTP command test failed (-5)");
////            }
////
////            // Test URI
////            if (!requestInfo.getUri().equals("/api/resource?id=123&name=test")) {
////                System.out.println("URI test failed (-5)");
////            }
////
////            // Test URI segments
////            String[] expectedUriSegments = {"api", "resource"};
////            if (!Arrays.equals(requestInfo.getUriSegments(), expectedUriSegments)) {
////                System.out.println("URI segments test failed (-5)");
////                for(String s : requestInfo.getUriSegments()){
////                    System.out.println(s);
////                }
////            }
////            // Test parameters
////            Map<String, String> expectedParams = new HashMap<>();
////            expectedParams.put("id", "123");
////            expectedParams.put("name", "test");
////            expectedParams.put("filename","\"hello_world.txt\"");
////            if (!requestInfo.getParameters().equals(expectedParams)) {
////                System.out.println("Parameters test failed (-5)");
////            }
////
////            // Test content
////            byte[] expectedContent = "hello world!\n".getBytes();
////            if (!Arrays.equals(requestInfo.getContent(), expectedContent)) {
////                System.out.println("Content test failed (-5)");
////            }
////            input.close();
////        } catch (IOException e) {
////            System.out.println("Exception occurred during parsing: " + e.getMessage() + " (-5)");
////        }
////
////        request = "GET /sub?a=10&b=3 HTTP/1.1\n" +
////                    "Host: localhost\n" +
////                    "Content-Length: 0\n" +
////                    "\n";
////
////        input=new BufferedReader(new InputStreamReader(new ByteArrayInputStream(request.getBytes())));
////
////        try {
////            RequestParser.RequestInfo requestInfo = RequestParser.parseRequest(input);
////        }
////        catch (IOException e) {
////            System.out.println("Exception occurred during parsing: " + e.getMessage() + " (-5)");
////        }
////
////    }
////
////
////    public static void testServer() throws Exception{
////		// implement your own tests!
////        System.out.println("1num of threads " + Thread.activeCount());
////        // create server
////        MyHTTPServer server = new MyHTTPServer(8080, 5);
////        server.addServlet("GET", "/sub", new SubServlet());
////
////
////        server.start();
////        System.out.println("2num of threads " + Thread.activeCount());
////
////        // timeout
////        Thread.sleep(1000);
////
////        int numOfThreads = Thread.activeCount();
////
////        if (numOfThreads != 2) {
////            return;
////        }
////
////
////        try {
////            // create a client
////            Socket client = new Socket("localhost", 8080);
////
////            // send a request
////            OutputStream out = client.getOutputStream();
////            //        String request = """
////            //                GET /sub?a=10&b=3 HTTP/1.1
////            //                Host: localhost
////            //                Content-Length: 0
////            //
////            //                """;
////            String request = "GET /sub?a=10&b=3 HTTP/1.1\n" +
////                    "Host: localhost\n" +
////                    "Content-Length: 0\n" +
////                    "\n";
////            out.write(request.getBytes());
////            // flush the output stream to make sure the request is sent
////            out.flush();
////
////            Thread.sleep(1000);
////
////            System.out.println(Thread.activeCount());
////
////            // Get the response
////            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
////            String responseLine;
////            while ((responseLine = in.readLine()) != null) {
////                if (responseLine.startsWith("Result:")) {
////                    System.out.println(responseLine);
////                    break;
////                }
////            }
////             // close the client and all resources
////            out.close();
////            in.close();
////            client.close();
////
////        } catch (Exception e) {
////            e.printStackTrace();
////        }
////
////
////        try {
////            server.close();
////        }
////        catch (Exception e)
////        {
////            e.printStackTrace();
////        }
////
////
////        // wait 2 seconds for all threads to close
////        Thread.sleep(2000);
////
////        System.out.println(Thread.activeCount());
////
////    }
////
////    public static void main(String[] args) {
////        testParseRequest(); // 40 points
////        try{
////            testServer(); // 60
////        }catch(Exception e){
////            System.out.println("your server throwed an exception (-60)");
////        }
////        System.out.println(Thread.activeCount());
////        System.out.println("done");
////    }
////
////}
//
//
//package graph;
//
//import java.io.BufferedReader;
//import java.io.ByteArrayInputStream;
//import java.io.IOException;
//import java.io.InputStreamReader;
//import java.io.OutputStream;
//import java.io.PrintWriter;
//import java.net.Socket;
//import java.util.Arrays;
//import java.util.HashMap;
//import java.util.Map;
//import java.util.Random;
//import java.util.concurrent.ThreadPoolExecutor;
//
//import server.RequestParser.RequestInfo;
//import servlet.SubServlet;
//
//
//public class MainTrain { // RequestParser
//
//
//    private static void testParseRequest() {
//        // Test data
//        String request = "GET /api/resource?id=123&name=test HTTP/1.1\n" +
//                "Host: example.com\n" +
//                "Content-Length: 5\n"+
//                "\n" +
//                "filename=\"hello_world.txt\"\n"+
//                "\n" +
//                "hello world!\n"+
//                "\n" ;
//        /*String request = "GET /calculate?a=5&b=3 HTTP/1.1\n" +
//                "Host: localhost\n" +
//                "\n";*/
//
//        BufferedReader input=new BufferedReader(new InputStreamReader(new ByteArrayInputStream(request.getBytes())));
//        try {
//            server.RequestParser.RequestInfo requestInfo = server.RequestParser.parseRequest(input);
//
//            // Test HTTP command
//            if (!requestInfo.getHttpCommand().equals("GET")) {
//                System.out.println("HTTP command test failed (-5)");
//            }
//
//            // Test URI
//            if (!requestInfo.getUri().equals("/api/resource?id=123&name=test")) {
//                System.out.println("URI test failed (-5)");
//            }
//
//            // Test URI segments
//            String[] expectedUriSegments = {"api", "resource"};
//            if (!Arrays.equals(requestInfo.getUriSegments(), expectedUriSegments)) {
//                System.out.println("URI segments test failed (-5)");
//                for(String s : requestInfo.getUriSegments()){
//                    System.out.println(s);
//                }
//            }
//            // Test parameters
//            Map<String, String> expectedParams = new HashMap<>();
//            expectedParams.put("id", "123");
//            expectedParams.put("name", "test");
//            expectedParams.put("filename","\"hello_world.txt\"");
//            if (!requestInfo.getParameters().equals(expectedParams)) {
//                System.out.println("Parameters test failed (-5)");
//            }
//
//            // Test content
//            byte[] expectedContent = "hello world!\n".getBytes();
//            if (!Arrays.equals(requestInfo.getContent(), expectedContent)) {
//                System.out.println("Content test failed (-5)");
//            }
//            input.close();
//        } catch (IOException e) {
//            System.out.println("Exception occurred during parsing: " + e.getMessage() + " (-5)");
//        }
//    }
//
//
//    public static void testServer() throws Exception
//    {
//        try {
//            // Count active threads before starting the server
//            int initialThreadCount = Thread.activeCount();
//            //System.out.println("initialThreadCount: "+initialThreadCount);
//            // Step 1: Create the server
//            server.MyHTTPServer server = new server.MyHTTPServer(8080, 5);
//            server.addServlet("GET", "/calculate", new SubServlet());
//
//
//
//            // Step 2: Start the server
//            server.start();
//
//            // Give the server some time to start up
//            Thread.sleep(1000);
//
//            // Count active threads after starting the server
//            int threadCountAfterStart = Thread.activeCount();
//            //System.out.println("threadCountAfterStart: "+threadCountAfterStart);
//
////            // Check that only one new thread has been created
////            if (threadCountAfterStart == initialThreadCount + 1) {
////                System.out.println("Server started with one additional thread.");
////            } else {
////                System.err.println("Server did not start with one additional thread. Initial: "
////                        + initialThreadCount + ", After start: " + threadCountAfterStart);
////            }
//
//            //active count This represents the approximate number of threads that are actively executing task.
//            //This represents the current number of threads in the pool. This includes both active threads (executing tasks) and idle threads (waiting for tasks).
//            ThreadPoolExecutor threadPoolExecutor = (ThreadPoolExecutor) server.getThreadPool();
//            int initialActiveCount = threadPoolExecutor.getActiveCount();
//            int initialPoolSize = threadPoolExecutor.getPoolSize();
//
//
//
//
//            // Step 3: Create a client socket to connect to the server
//            try (Socket clientSocket = new Socket("localhost", 8080))
//            {
//                // Step 4: Send an appropriate HTTP request to the server
//                OutputStream outputStream = clientSocket.getOutputStream();
//                String request = "GET /calculate?a=5&b=3 HTTP/1.1\n" +
//                        "Host: localhost\n" +
//                        "\n";
//                outputStream.write(request.getBytes());
//                //make sure that the request is sent immediately after it is written to the output stream
//                outputStream.flush();
//
//
//                // Give the server some time to process the request so we can see the change in the pool size and active count
//                Thread.sleep(1000);
//
//                // Step 6: Monitor thread pool state after client connection,we want to check that if the server is work
//                //when a client is connected to him it create for him a new thread
//                int currentActiveCount = threadPoolExecutor.getActiveCount();
//                int currentPoolSize = threadPoolExecutor.getPoolSize();
//                //get the number of active threads
//                int current_num_therad= Thread.activeCount();
//                //System.out.println("current_num_therad: "+current_num_therad);
//
//
//
//                // Step 5: Read and validate the server's response
//                BufferedReader reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
//                String line;
//                while ((line = reader.readLine()) != null)
//                {
//                    System.out.println(line); // Print server response for verification
//                    if (line.contains("Sum: "))
//                    {
//                        break;
//                    }
//                }
//                //close all the resources
//                outputStream.close();
//                reader.close();
//            }
//
//            //int check=Thread.activeCount();
//            //System.out.println("check: "+check);
//            // Step 7: Shut down the server
//            server.close();
//
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//
//
//        // Give the server some time to shut down
//        Thread.sleep(2000);
//        //print the number of threads after the server is closed
//        int final_num_thread=Thread.activeCount();
//        //System.out.println("final_num_thread: "+final_num_thread);
//
//
//    }
//
//
//    public static void main(String[] args) {////package graph;
//////
//////import java.io.BufferedReader;
//////import java.io.ByteArrayInputStream;
//////import java.io.IOException;
//////import java.io.InputStreamReader;
//////import java.io.OutputStream;
//////import java.net.Socket;
//////import java.util.Arrays;
//////import java.util.HashMap;
//////import java.util.Map;
//////import java.util.concurrent.ThreadPoolExecutor;
//////
//////import server.MyHTTPServer;
//////import server.RequestParser;
//////import servlet.SubServlet;
//////
//////public class MainTrain { // RequestParser
//////
//////
//////    private static void testParseRequest() {
//////        // Test data
//////
//////        String request = "GET /api/resource?id=123&name=test HTTP/1.1\n" +
//////                            "Host: example.com\n" +
//////                            "Content-Length: 5\n"+
//////                            "\n" +
//////                            "filename=\"hello_world.txt\"\n"+
//////                            "\n" +
//////                            "hello world!\n"+
//////                            "\n" ;
//////
//////        BufferedReader input=new BufferedReader(new InputStreamReader(new ByteArrayInputStream(request.getBytes())));
//////        try {
//////            RequestParser.RequestInfo requestInfo = RequestParser.parseRequest(input);
//////
//////            // Test HTTP command
//////            if (!requestInfo.getHttpCommand().equals("GET")) {
//////                System.out.println("HTTP command test failed (-5)");
//////            }
//////
//////            // Test URI
//////            if (!requestInfo.getUri().equals("/api/resource?id=123&name=test")) {
//////                System.out.println("URI test failed (-5)");
//////            }
//////
//////            // Test URI segments
//////            String[] expectedUriSegments = {"api", "resource"};
//////            if (!Arrays.equals(requestInfo.getUriSegments(), expectedUriSegments)) {
//////                System.out.println("URI segments test failed (-5)");
//////                for(String s : requestInfo.getUriSegments()){
//////                    System.out.println(s);
//////                }
//////            }
//////            // Test parameters
//////            Map<String, String> expectedParams = new HashMap<>();
//////            expectedParams.put("id", "123");
//////            expectedParams.put("name", "test");
//////            expectedParams.put("filename","\"hello_world.txt\"");
//////            if (!requestInfo.getParameters().equals(expectedParams)) {
//////                System.out.println("Parameters test failed (-5)");
//////            }
//////
//////            // Test content
//////            byte[] expectedContent = "hello world!\n".getBytes();
//////            if (!Arrays.equals(requestInfo.getContent(), expectedContent)) {
//////                System.out.println("Content test failed (-5)");
//////            }
//////            input.close();
//////        } catch (IOException e) {
//////            System.out.println("Exception occurred during parsing: " + e.getMessage() + " (-5)");
//////        }
//////
//////        request = "GET /sub?a=10&b=3 HTTP/1.1\n" +
//////                    "Host: localhost\n" +
//////                    "Content-Length: 0\n" +
//////                    "\n";
//////
//////        input=new BufferedReader(new InputStreamReader(new ByteArrayInputStream(request.getBytes())));
//////
//////        try {
//////            RequestParser.RequestInfo requestInfo = RequestParser.parseRequest(input);
//////        }
//////        catch (IOException e) {
//////            System.out.println("Exception occurred during parsing: " + e.getMessage() + " (-5)");
//////        }
//////
//////    }
//////
//////
//////    public static void testServer() throws Exception{
//////		// implement your own tests!
//////        System.out.println("1num of threads " + Thread.activeCount());
//////        // create server
//////        MyHTTPServer server = new MyHTTPServer(8080, 5);
//////        server.addServlet("GET", "/sub", new SubServlet());
//////
//////
//////        server.start();
//////        System.out.println("2num of threads " + Thread.activeCount());
//////
//////        // timeout
//////        Thread.sleep(1000);
//////
//////        int numOfThreads = Thread.activeCount();
//////
//////        if (numOfThreads != 2) {
//////            return;
//////        }
//////
//////
//////        try {
//////            // create a client
//////            Socket client = new Socket("localhost", 8080);
//////
//////            // send a request
//////            OutputStream out = client.getOutputStream();
//////            //        String request = """
//////            //                GET /sub?a=10&b=3 HTTP/1.1
//////            //                Host: localhost
//////            //                Content-Length: 0
//////            //
//////            //                """;
//////            String request = "GET /sub?a=10&b=3 HTTP/1.1\n" +
//////                    "Host: localhost\n" +
//////                    "Content-Length: 0\n" +
//////                    "\n";
//////            out.write(request.getBytes());
//////            // flush the output stream to make sure the request is sent
//////            out.flush();
//////
//////            Thread.sleep(1000);
//////
//////            System.out.println(Thread.activeCount());
//////
//////            // Get the response
//////            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
//////            String responseLine;
//////            while ((responseLine = in.readLine()) != null) {
//////                if (responseLine.startsWith("Result:")) {
//////                    System.out.println(responseLine);
//////                    break;
//////                }
//////            }
//////             // close the client and all resources
//////            out.close();
//////            in.close();
//////            client.close();
//////
//////        } catch (Exception e) {
//////            e.printStackTrace();
//////        }
//////
//////
//////        try {
//////            server.close();
//////        }
//////        catch (Exception e)
//////        {
//////            e.printStackTrace();
//////        }
//////
//////
//////        // wait 2 seconds for all threads to close
//////        Thread.sleep(2000);
//////
//////        System.out.println(Thread.activeCount());
//////
//////    }
//////
//////    public static void main(String[] args) {
//////        testParseRequest(); // 40 points
//////        try{
//////            testServer(); // 60
//////        }catch(Exception e){
//////            System.out.println("your server throwed an exception (-60)");
//////        }
//////        System.out.println(Thread.activeCount());
//////        System.out.println("done");
//////    }
//////
//////}
////
////
////package graph;
////
////import java.io.BufferedReader;
////import java.io.ByteArrayInputStream;
////import java.io.IOException;
////import java.io.InputStreamReader;
////import java.io.OutputStream;
////import java.io.PrintWriter;
////import java.net.Socket;
////import java.util.Arrays;
////import java.util.HashMap;
////import java.util.Map;
////import java.util.Random;
////import java.util.concurrent.ThreadPoolExecutor;
////
////import server.RequestParser.RequestInfo;
////import servlet.SubServlet;
////
////
////public class MainTrain { // RequestParser
////
////
////    private static void testParseRequest() {
////        // Test data
////        String request = "GET /api/resource?id=123&name=test HTTP/1.1\n" +
////                "Host: example.com\n" +
////                "Content-Length: 5\n"+
////                "\n" +
////                "filename=\"hello_world.txt\"\n"+
////                "\n" +
////                "hello world!\n"+
////                "\n" ;
////        /*String request = "GET /calculate?a=5&b=3 HTTP/1.1\n" +
////                "Host: localhost\n" +
////                "\n";*/
////
////        BufferedReader input=new BufferedReader(new InputStreamReader(new ByteArrayInputStream(request.getBytes())));
////        try {
////            server.RequestParser.RequestInfo requestInfo = server.RequestParser.parseRequest(input);
////
////            // Test HTTP command
////            if (!requestInfo.getHttpCommand().equals("GET")) {
////                System.out.println("HTTP command test failed (-5)");
////            }
////
////            // Test URI
////            if (!requestInfo.getUri().equals("/api/resource?id=123&name=test")) {
////                System.out.println("URI test failed (-5)");
////            }
////
////            // Test URI segments
////            String[] expectedUriSegments = {"api", "resource"};
////            if (!Arrays.equals(requestInfo.getUriSegments(), expectedUriSegments)) {
////                System.out.println("URI segments test failed (-5)");
////                for(String s : requestInfo.getUriSegments()){
////                    System.out.println(s);
////                }
////            }
////            // Test parameters
////            Map<String, String> expectedParams = new HashMap<>();
////            expectedParams.put("id", "123");
////            expectedParams.put("name", "test");
////            expectedParams.put("filename","\"hello_world.txt\"");
////            if (!requestInfo.getParameters().equals(expectedParams)) {
////                System.out.println("Parameters test failed (-5)");
////            }
////
////            // Test content
////            byte[] expectedContent = "hello world!\n".getBytes();
////            if (!Arrays.equals(requestInfo.getContent(), expectedContent)) {
////                System.out.println("Content test failed (-5)");
////            }
////            input.close();
////        } catch (IOException e) {
////            System.out.println("Exception occurred during parsing: " + e.getMessage() + " (-5)");
////        }
////    }
////
////
////    public static void testServer() throws Exception
////    {
////        try {
////            // Count active threads before starting the server
////            int initialThreadCount = Thread.activeCount();
////            //System.out.println("initialThreadCount: "+initialThreadCount);
////            // Step 1: Create the server
////            server.MyHTTPServer server = new server.MyHTTPServer(8080, 5);
////            server.addServlet("GET", "/calculate", new SubServlet());
////
////
////
////            // Step 2: Start the server
////            server.start();
////
////            // Give the server some time to start up
////            Thread.sleep(1000);
////
////            // Count active threads after starting the server
////            int threadCountAfterStart = Thread.activeCount();
////            //System.out.println("threadCountAfterStart: "+threadCountAfterStart);
////
//////            // Check that only one new thread has been created
//////            if (threadCountAfterStart == initialThreadCount + 1) {
//////                System.out.println("Server started with one additional thread.");
//////            } else {
//////                System.err.println("Server did not start with one additional thread. Initial: "
//////                        + initialThreadCount + ", After start: " + threadCountAfterStart);
//////            }
////
////            //active count This represents the approximate number of threads that are actively executing task.
////            //This represents the current number of threads in the pool. This includes both active threads (executing tasks) and idle threads (waiting for tasks).
////            ThreadPoolExecutor threadPoolExecutor = (ThreadPoolExecutor) server.getThreadPool();
////            int initialActiveCount = threadPoolExecutor.getActiveCount();
////            int initialPoolSize = threadPoolExecutor.getPoolSize();
////
////
////
////
////            // Step 3: Create a client socket to connect to the server
////            try (Socket clientSocket = new Socket("localhost", 8080))
////            {
////                // Step 4: Send an appropriate HTTP request to the server
////                OutputStream outputStream = clientSocket.getOutputStream();
////                String request = "GET /calculate?a=5&b=3 HTTP/1.1\n" +
////                        "Host: localhost\n" +
////                        "\n";
////                outputStream.write(request.getBytes());
////                //make sure that the request is sent immediately after it is written to the output stream
////                outputStream.flush();
////
////
////                // Give the server some time to process the request so we can see the change in the pool size and active count
////                Thread.sleep(1000);
////
////                // Step 6: Monitor thread pool state after client connection,we want to check that if the server is work
////                //when a client is connected to him it create for him a new thread
////                int currentActiveCount = threadPoolExecutor.getActiveCount();
////                int currentPoolSize = threadPoolExecutor.getPoolSize();
////                //get the number of active threads
////                int current_num_therad= Thread.activeCount();
////                //System.out.println("current_num_therad: "+current_num_therad);
////
////
////
////                // Step 5: Read and validate the server's response
////                BufferedReader reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
////                String line;
////                while ((line = reader.readLine()) != null)
////                {
////                    System.out.println(line); // Print server response for verification
////                    if (line.contains("Sum: "))
////                    {
////                        break;
////                    }
////                }
////                //close all the resources
////                outputStream.close();
////                reader.close();
////            }
////
////            //int check=Thread.activeCount();
////            //System.out.println("check: "+check);
////            // Step 7: Shut down the server
////            server.close();
////
////
////        } catch (Exception e) {
////            e.printStackTrace();
////        }
////
////
////
////        // Give the server some time to shut down
////        Thread.sleep(2000);
////        //print the number of threads after the server is closed
////        int final_num_thread=Thread.activeCount();
////        //System.out.println("final_num_thread: "+final_num_thread);
////
////
////    }
////
////
////    public static void main(String[] args) {
////        testParseRequest(); // 40 points
////        try{
////           testServer(); // 60
////        }catch(Exception e){
////            System.out.println("your server throwed an exception (-60)");
////        }
////        System.out.println("done");
////        System.exit(0);
////    }
////
////}
////
//
//
//
//package graph;
//import server.*;
//import servlet.*;
//
//public class MainTrain {
//    public static void main(String[] args) throws Exception {
//        HTTPServer server=new MyHTTPServer(8080,5);
//        server.addServlet("GET", "/publish", new TopicDisplayer());
//        server.addServlet("POST", "/upload", new ConfLoader());
//        server.addServlet("GET", "/app/", new HtmlLoader(System.getProperty("user.dir") + "/html_files"));
//
//        server.start();
//        System.in.read();
//        server.close();
//        System.out.println("done");
//
//    }
//}
//        testParseRequest(); // 40 points
//        try{
//           testServer(); // 60
//        }catch(Exception e){
//            System.out.println("your server throwed an exception (-60)");
//        }
//        System.out.println("done");
//        System.exit(0);
//    }
//
//}
//



package graph;
import server.*;
import servlet.*;

public class MainTrain {
    public static void main(String[] args) throws Exception {
        HTTPServer server = new MyHTTPServer(8080, 5);
        server.addServlet("GET", "/publish", new TopicDisplayer());
        server.addServlet("POST", "/upload", new ConfLoader());
        server.addServlet("GET", "/app/", new HtmlLoader(System.getProperty("user.dir") + "/html_files"));

        server.start();
        System.in.read();
        server.close();
        System.out.println("done");

    }
}
//package graph;
//import java.util.Random;
//
//
//public class MainTrain {
//
//    public static void main(String[] args) {
//        int c=Thread.activeCount();
//        GenericConfig gc=new GenericConfig();
//        gc.setConfFile("/Users/ccg/IdeaProjects/EX1/config_files/simple2.conf"); // change to the exact loaction where you put the file.
//        gc.create();
//
//        if(Thread.activeCount()!=c+2){
//            System.out.println("the configuration did not create the right number of threads (-10)");
//        }
//
//        double result[]={0.0};
//
//        TopicManagerSingleton.get().getTopic("D").subscribe(new Agent() {
//
//            @Override
//            public String getName() {
//                return "";
//            }
//
//            @Override
//            public void reset() {
//            }
//
//            @Override
//            public void callback(String topic, Message msg) {
//                result[0]=msg.asDouble;
//            }
//
//            @Override
//            public void close() {
//            }
//
//        });
//
//        Random r=new Random();
//        for(int i=0;i<9;i++){
//            int x,y;
//            x=r.nextInt(1000);
//            y=r.nextInt(1000);
//            TopicManagerSingleton.get().getTopic("A").publish(new Message(x));
//            TopicManagerSingleton.get().getTopic("B").publish(new Message(y));
//
//            try {
//                Thread.sleep(100);
//            } catch (InterruptedException e) {}
//
//            if(result[0]!=x+y+1){
//                System.out.println("your agents did not produce the desierd result (-10)");
//            }
//        }
//
//        gc.close();
//
//        try {
//            Thread.sleep(100);
//        } catch (InterruptedException e) {}
//
//        if(Thread.activeCount()!=c){
//            System.out.println("your code did not close all threads (-10)");
//        }
//
//        System.out.println("done");
//
//    }
//}
