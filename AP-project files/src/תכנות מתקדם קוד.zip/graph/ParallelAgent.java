package graph;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class ParallelAgent implements Agent {

    // store the agent and the queue
    private Agent agent;
    private BlockingQueue<Message> queue;
    // store the running flag for the thread
    private volatile boolean running = true;
    // store the thread
    private Thread readingFromQueueThread;


    //constructor
    ParallelAgent(Agent agent, int capacity){
        this.agent = agent;
        this.queue = new ArrayBlockingQueue<>(capacity);

        // run a thread that will take messages from the queue
        // and activate the callback method of agent:
        this.readingFromQueueThread = new Thread(() -> {
            // while running=true, the thread will keep running
            while (this.running) {
                try {
                    // thread will sleep until a message is available in the queue
                    Message msgFromQueue = queue.take();
                    // split the topic from the message using the ":" separator
                    String topic = msgFromQueue.asText.split(":")[0];
                    String message = msgFromQueue.asText.split(":")[1];

                    // call the callback method of the agent
                    agent.callback(topic, new Message(message));
                }
                catch (InterruptedException e) {
                    // No need to print the exception message
                    //e.printStackTrace();
                }
            }
        });
        // start the thread
        this.readingFromQueueThread.start();
    }

    @Override
    public String getName() {
        return agent.getName();
    }

    @Override
    public void reset() {
        agent.reset();
    }

    @Override
    public void callback(String topic, Message msg) {
        try {
            // add a message and the topic to the queue
            this.queue.put(new Message(topic + ":" + msg.asText));
        }
        catch (InterruptedException e) {
            // No need to print the exception message
            //e.printStackTrace();
        }
    }

    @Override
    public void close() {
        // change the running flag to false
        this.running = false;
        // stop the thread from the constructor
        this.readingFromQueueThread.interrupt();
        agent.close();
    }
}
