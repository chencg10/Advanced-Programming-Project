package graph;

import configs.Node;
import java.util.ArrayList;
import java.util.HashMap;
import graph.TopicManagerSingleton.TopicManager;

public class Graph extends ArrayList<Node>{

    public Graph(){
        super();
    }

    public boolean hasCycles() {
        // for each node in the graph, check if it has a cycle in its subcomponents
        for (Node node : this) {
            if (node.hasCycles()) {
                return true;
            }
        }
        return false;
    }

    public void createFromTopics() {
        TopicManager tm = TopicManagerSingleton.get();

        // get topics
        Topic[] topics = tm.getTopics().values().toArray(new Topic[0]);

        // create hashmap to remember the nodes
        HashMap<String, Node> nodes = new HashMap<>();

        // for each topic, create a node
        for (Topic curTopic : topics) {
            // create a node
            Node curNode = nodes.get("T" + curTopic.getName());

            if (curNode == null) {
                // create a new node
                curNode = new Node("T" + curTopic.getName());
                // add it to the hashmap
                nodes.put(curNode.getName(), curNode);
                // add it to the graph
                this.add(curNode);
            }

            // get the subscribers
            for (Agent agent : curTopic.getSubscribers()) {
                // get the node
                Node subNode = nodes.get("A" + agent.getName());
                if (subNode == null) {
                    // create a new node
                    subNode = new Node("A" + agent.getName());
                    // add it to the hashmap
                    nodes.put(subNode.getName(), subNode);
                    // add it to the graph
                    this.add(subNode);
                }
                // add an edge from the current node to the subscriber node
                curNode.addEdge(subNode);
            }

            // get the publishers
            for (Agent agent : curTopic.getPublishers()) {
                // get the node
                Node pubNode = nodes.get("A" + agent.getName());
                if (pubNode == null) {
                    // create a new node
                    pubNode = new Node("A" + agent.getName());
                    // add it to the hashmap
                    nodes.put(pubNode.getName(), pubNode);
                    // add it to the graph
                    this.add(pubNode);
                }
                // add an edge from the publisher node to the current node
                pubNode.addEdge(curNode);
            }
        }

    }

    private Node getNode(String topic) {
        return this.get(this.indexOf(new Node(topic)));
    }

}
