package graph;

import configs.Config;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class GenericConfig implements Config {
    private List<String> lines;
    private List<Agent> agents = new ArrayList<>();

    public void setConfFile(String file_path) {
        try {
            // read all the lines from the file
            lines = Files.readAllLines(Paths.get(file_path));
        } catch (IOException e) {
           // e.printStackTrace();
        }
    }

    @Override
    public void create() {

        // if the length of the lines is not devisible by 3 do nothing
        if (lines.size() % 3 != 0) {
            return;
        }

        // iterate over the lines and for each 3 lines, create the proper agent
        for (int i = 0; i < lines.size(); i += 3) {
            // first line is agent full name
            String agentName = lines.get(i);
            // filter out the project name
            agentName = agentName.substring(agentName.indexOf('.') + 1);
            // second line is agent subscriptions
            String[] subs = lines.get(i + 1).split(",");
            // third line is agent publications
            String[] pubs = lines.get(i + 2).split(",");

            // use class<?> to create the agent
            Agent temp = null;
            try {
                Class<?> agentClass = Class.forName(agentName);
                // call the right constructor using the agent class name
                temp = (Agent) agentClass.getConstructor(String[].class, String[].class).newInstance((Object) subs, (Object) pubs);
            } catch (Exception e) {
                //e.printStackTrace();
            }

            // warp it with parallel agent and add the agent to the list of agents
            if (temp != null) {
                agents.add(new ParallelAgent(temp, 10));
            }
        }
    }

    @Override
    public String getName() {
        return "GenericConfig";
    }

    @Override
    public int getVersion() {
        return 0;
    }

    @Override
    public void close() {
        // close all the agents
        for (Agent agent : agents) {
            agent.close();
        }
    }
}
